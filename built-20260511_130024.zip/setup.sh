#!/usr/bin/env bash
set -euo pipefail
D="$HOME/.helios"
CF="$D/bin/cloudflared"
export HELIOS_PORT="${HELIOS_PORT:-8765}"
export HELIOS_FPS="${HELIOS_FPS:-60}"
export HELIOS_QUALITY="${HELIOS_QUALITY:-75}"
export HELIOS_TITLE="${HELIOS_TITLE:-Helios}"
export HELIOS_ACCENT="${HELIOS_ACCENT:-#f97316}"
_e(){ printf "\033[1;31m✗\033[0m  %s\n" "$*">&2;exit 1;}
_w(){ printf "\033[1;33m⚠\033[0m  %s\n" "$*">&2;}
_p(){ printf "\033[1;34m→\033[0m  %s\n" "$*";}
_o(){ printf "\033[1;32m✓\033[0m  %s\n" "$*";}
printf "\n  \033[1;33m╔══════════════════════════════════╗\033[0m\n"
printf "  \033[1;33m║  ☀   Helios Remote Desktop   ☀  ║\033[0m\n"
printf "  \033[1;33m╚══════════════════════════════════╝\033[0m\n\n"
[[ "$(uname)" == "Darwin" ]]||_e "macOS only."
command -v python3 &>/dev/null||_e "python3 not found."
python3 -c "import sys;assert sys.version_info>=(3,8)"||_e "Python 3.8+ required."
_o "Python $(python3 --version|awk '{print $2}')"
_p "Checking cloudflared..."
if ! command -v cloudflared &>/dev/null&&[[ ! -x "$CF" ]];then
  mkdir -p "$D/bin"
  if command -v brew &>/dev/null;then
    brew install --quiet cloudflared
  else
    _A=$(uname -m);[[ "$_A" == "arm64" ]]&&_A="arm64"||_A="amd64"
    curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-darwin-${_A}" -o "$CF"
    chmod +x "$CF"
  fi
fi
CLOUDFLARED=$(command -v cloudflared 2>/dev/null||echo "$CF")
_o "cloudflared ready"

# ── BlackHole (system audio loopback) ────────────────────────────────────────
_p "Checking BlackHole (system audio)..."
_BH_OK=false
# Check if any BlackHole device already exists in CoreAudio
if system_profiler SPAudioDataType 2>/dev/null | grep -qi "blackhole"; then
  _BH_OK=true
fi
if [[ "$_BH_OK" == false ]]; then
  if command -v brew &>/dev/null; then
    _p "Installing BlackHole 2ch via Homebrew..."
    brew install --quiet blackhole-2ch && _BH_OK=true
  else
    _w "Homebrew not found — cannot auto-install BlackHole."
    _w "Install it manually: https://github.com/ExistentialAudio/BlackHole"
  fi
fi

if [[ "$_BH_OK" == true ]]; then
  _o "BlackHole ready"
  # Create a Multi-Output Device (speakers + BlackHole) via Python/CoreAudio
  # so the user still hears audio while Helios captures it.
  python3 - <<'PYEOF'
import subprocess, sys

# Check if the aggregate device already exists
out = subprocess.run(
    ["system_profiler", "SPAudioDataType"],
    capture_output=True, text=True
).stdout
if "Helios Loopback" in out:
    print("  Aggregate device 'Helios Loopback' already exists.")
    sys.exit(0)

# Use SwitchAudioSource if available (brew install switchaudio-osx) to list;
# otherwise just print instructions.
try:
    devs = subprocess.run(
        ["SwitchAudioSource", "-a", "-t", "output"],
        capture_output=True, text=True, check=True
    ).stdout.strip().splitlines()
    # Find the default speaker name
    default = subprocess.run(
        ["SwitchAudioSource", "-c"],
        capture_output=True, text=True, check=True
    ).stdout.strip()
    print(f"  Default output: {default}")
    print()
    print("  \033[1;33mTo hear audio while Helios streams it, create a Multi-Output Device:\033[0m")
    print("  1. Open Audio MIDI Setup  (Spotlight → 'Audio MIDI Setup')")
    print("  2. Click + → 'Create Multi-Output Device'")
    print(f"  3. Tick both '{default}' and 'BlackHole 2ch'")
    print("  4. Name it 'Helios Loopback'")
    print("  5. Set it as your system output (right-click → 'Use This Device for Sound Output')")
    print()
    print("  Helios will then stream everything you hear.")
except FileNotFoundError:
    print()
    print("  \033[1;33mTo hear audio while Helios streams it:\033[0m")
    print("  1. Open Audio MIDI Setup  (Spotlight → 'Audio MIDI Setup')")
    print("  2. Click + → 'Create Multi-Output Device'")
    print("  3. Tick your speakers AND 'BlackHole 2ch'")
    print("  4. Set that device as your system output in System Settings → Sound")
    print()
PYEOF
else
  _w "Audio streaming will use the default microphone input instead."
  _w "For true system audio, install BlackHole: https://github.com/ExistentialAudio/BlackHole"
fi

_p "Creating Python environment..."
rm -rf "$D/.venv"
if ! python3 -m venv "$D/.venv" 2>/dev/null; then
  _w "venv with bundled pip failed (Python missing ensurepip) — bootstrapping pip manually."
  rm -rf "$D/.venv"
  python3 -m venv --without-pip "$D/.venv" || _e "python3 -m venv failed"
  curl -fsSL https://bootstrap.pypa.io/get-pip.py -o "$D/.get-pip.py"
  "$D/.venv/bin/python" "$D/.get-pip.py" --quiet
  rm -f "$D/.get-pip.py"
fi
"$D/.venv/bin/python" -m pip install --quiet --upgrade pip
"$D/.venv/bin/python" -m pip install --quiet -r "$D/requirements.txt"
_o "Dependencies installed"
printf "\n"
_w "Required: System Settings -> Privacy & Security"
printf "       -> Screen Recording : enable Terminal\n"
printf "       -> Accessibility    : enable Terminal\n\n"
while true;do
  printf "  Password (min 4): ";IFS= read -rs _PW</dev/tty;echo
  [[ ${#_PW} -ge 4 ]]||{ _w "Too short.";continue;}
  printf "  Confirm:          ";IFS= read -rs _PW2</dev/tty;echo
  [[ "$_PW" == "$_PW2" ]]&&break;_w "No match."
done
printf "\n"
export HELIOS_PASSWORD="$_PW"
unset _PW _PW2
_p "Starting server..."
"$D/.venv/bin/python3" "$D/helios_core.py">>"$D/server.log" 2>&1&
_SRV=$!
_R=false
for _i in $(seq 1 40);do
  nc -z 127.0.0.1 "$HELIOS_PORT" 2>/dev/null&&{ _R=true;break;}
  sleep 0.25
done
[[ "$_R" == true ]]||_e "Server failed. See $D/server.log"
_o "Server running (PID $_SRV · port $HELIOS_PORT)"
trap 'kill "$_SRV" 2>/dev/null||true;printf "\n";_o "Stopped.";exit 0' EXIT INT TERM
_p "Opening Cloudflare tunnel..."
printf "\n"
_SU=false
while IFS= read -r _L;do
  [[ "$_L" == *ERR*||"$_L" == *WRN*||"$_L" == *"Registered"*||"$_L" == *"trycloudflare"* ]]&&printf "  %s\n" "$_L"
  if [[ "$_SU" == false&&"$_L" == *"trycloudflare.com"* ]];then
    _U=$(printf '%s' "$_L"|grep -oE 'https://[^ |]+trycloudflare\.com[^ |]*'||true)
    if [[ -n "$_U" ]];then
      _SU=true
      printf "\n  \033[1;33m╔══════════════════════════════════════════════════════════════╗\033[0m\n"
      printf "  \033[1;33m║  ☀  %-57s║\033[0m\n" "$_U"
      printf "  \033[1;33m║  Open in any browser. Ctrl+C to stop.                       ║\033[0m\n"
      printf "  \033[1;33m╚══════════════════════════════════════════════════════════════╝\033[0m\n\n"
    fi
  fi
done < <("$CLOUDFLARED" tunnel --url "http://localhost:${HELIOS_PORT}" 2>&1)
